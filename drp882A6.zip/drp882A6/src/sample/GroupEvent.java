package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import java.util.ArrayList;

public class GroupEvent implements Event {
    Groupable theGroup;
    BlobModel theModel;
    InteractionModel iModel;

    GroupEvent(Groupable group, BlobModel model){
        theModel = model;
        theGroup = group;
    }

    public void doIt(){
        for (Groupable g : theGroup.getChildren()){
            theModel.items.remove(g);
        }
        theModel.items.add(theGroup);
    }

    public void undo(){
        for (Groupable g : theGroup.getChildren()){
            theModel.items.add(g);
        }
        theModel.items.remove(theGroup);
    }

    public String toString(){
        return "Grouped " + theGroup.getChildren().size() + " things into one group.";
    }
}

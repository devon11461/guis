package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/

import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

public class InteractionModel {
    ArrayList<Groupable> selection;
    ArrayList<BlobModelListener> subscribers;
    RubberRectangle rubber;
    boolean controlDown;
    double viewWidth, viewHeight;
    ArrayList<Groupable> clipboard = new ArrayList<>();
    Text clipboardStatus;

    public InteractionModel() {
        subscribers = new ArrayList<>();
        selection = new ArrayList<>();
        rubber = null;
        controlDown = false;
    }

    public void setText (Text t){
        clipboardStatus = t;
    }
    public void recordViewSize(double w, double h) {
        viewWidth = w;
        viewHeight = h;
    }

    public void setControl(boolean isDown) {
        controlDown = isDown;
        notifySubscribers();
    }

    public void clearSelection() {
        selection.clear();
        notifySubscribers();
    }

    public void setSelection(Groupable g) {
        selection.clear();
        selection.add(g);
        notifySubscribers();
    }

    public void setSelection(ArrayList<Groupable> group) {
        selection = group;
        notifySubscribers();
    }

    public boolean isSelected(Groupable g) {
        return selection.contains(g);
    }

    public void createRubber(double x1, double y1) {
        rubber = new RubberRectangle(x1, y1);
    }

    public void setRubberEnd(double x2, double y2) {
        rubber.updateCoords(x2, y2);
        notifySubscribers();
    }

    public boolean hasRubberband() {
        return (rubber != null);
    }

    public void deleteRubber() {
        rubber = null;
        notifySubscribers();
    }

    public void addSubtractSelection(Groupable g) {
        if (selection.contains(g)) {
            selection.remove(g);
        } else {
            selection.add(g);
        }
        notifySubscribers();
    }

    public void addSubtractSelection(List<Groupable> set) {
        set.forEach(g -> addSubtractSelection(g));
    }

    public void addSubscriber (BlobModelListener aSub) {
        subscribers.add(aSub);
    }

    private void notifySubscribers() {
        subscribers.forEach(sub -> sub.modelChanged());
    }

    public void copySelection(){
        ArrayList<Groupable> copies = new ArrayList<>();
        for (Groupable g : selection){
            copies.add(copySelectionHelper(g));
        }
        clipboard = copies;
        String emptyString ="                                                                                                                                                                         ";
        clipboardStatus.setText(emptyString + "Clipboard: " + clipboard.size() + " items" + emptyString);
    }

    public Groupable copySelectionHelper(Groupable g){
        if (!g.hasChildren()){
            Blob hold = new Blob((g.getRight()+g.getLeft())/2, (g.getTop()+g.getBottom())/2);
            return hold;
        } else {
            BlobGroup group = new BlobGroup();
            for (Groupable gs : g.getChildren()){
                group.children.add(copySelectionHelper(gs));
            }
            return group;
        }
    }
    public void copyClipBoard(){
        ArrayList<Groupable> hold = new ArrayList<>();
        for (Groupable g : clipboard){
            hold.add(copySelectionHelper(g));
        }
        this.clipboard = hold;
    }

}

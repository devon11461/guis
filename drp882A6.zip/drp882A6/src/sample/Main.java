package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Main extends Application {
    BlobView view;
    BlobController controller;
    BlobModel model;
    InteractionModel iModel;

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();

        // create MVC components
        view = new BlobView(800,800);
        controller = new BlobController();
        model = new BlobModel();
        iModel = new InteractionModel();

        // connect MVC components
        view.setModel(model);
        view.setInteractionModel(iModel);
        controller.setModel(model);
        controller.setInteractionModel(iModel);
        model.addSubscriber(view);
        iModel.addSubscriber(view);

        // set up event handling
        view.setOnMousePressed(controller::handlePressed);
        view.setOnMouseDragged(controller::handleDrag);
        view.setOnMouseReleased(controller::handleRelease);
//        view.setOnKeyPressed(controller::handleKeyPressed);
//        view.setOnKeyReleased(controller::handleKeyReleased);

        root.setCenter(view);
        root.setLeft(model.undoList);
        root.setRight(model.redoList);
        primaryStage.setTitle("381 A6 Demo");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
        view.requestFocus();


        Button undoButton = new Button("Undo");
        Button redoButton = new Button("Redo");
        HBox bottomBox = new HBox();
        HBox redoBox = new HBox();
        HBox undoBox = new HBox();
        String emptyString ="                                                                                                                                                                          ";
        Text text = new Text(emptyString + "Clipboard: empty" + emptyString);
        undoBox.getChildren().add(undoButton);
        redoBox.getChildren().add(redoButton);
        bottomBox.getChildren().addAll(undoBox, text, redoBox);
        iModel.setText(text);

        redoBox.setAlignment(Pos.BOTTOM_RIGHT);
        undoBox.setAlignment(Pos.BOTTOM_LEFT);

        root.setBottom(bottomBox);

        undoButton.setOnAction(e -> model.undoFirst());
        redoButton.setOnAction(e -> model.redoFirst());
        root.setOnKeyPressed(e -> controller.handleKeyPressed(e));
        root.setOnKeyReleased(e -> controller.handleKeyReleased(e));
        root.setAlignment(redoButton, Pos.BOTTOM_RIGHT);
    }


    public static void main(String[] args) {
        launch(args);
    }
}

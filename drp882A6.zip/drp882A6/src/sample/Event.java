package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
public interface Event {

    public void doIt();
    public void undo();
    public String toString();
}

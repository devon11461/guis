package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import java.util.ArrayList;

public class CutEvent implements Event  {
    ArrayList<Groupable> cuts = new ArrayList<>();
    BlobModel model;
    CutEvent(ArrayList<Groupable> g, BlobModel model){
        this.model = model;
        for (Groupable b : g){
            cuts.add(b);
        }
    }

    public void doIt(){
        model.removeSome(cuts);
    }

    public void undo(){
        for (Groupable b : cuts) {
            model.items.add(b);
        }
    }

    public String toString(){
        return "Cut " + cuts.size() + " Groupable things.";
    }
}

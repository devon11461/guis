package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/

public class UnGroupEvent implements Event {
    Groupable group;
    BlobModel theModel;

    UnGroupEvent(Groupable b, BlobModel model){
        theModel = model;
        group = b;
    }

    public void doIt(){
        group.getChildren().forEach(i -> theModel.items.add(i));
        theModel.items.remove(group);
    }

    public void undo(){
        group.getChildren().forEach(child -> theModel.items.remove(child));
        theModel.items.add(group);
    }

    public String toString(){
        return "Ungroup 1 group into: " + group.getChildren().size() + " children.";
    }
}

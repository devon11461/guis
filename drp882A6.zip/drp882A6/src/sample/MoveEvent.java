package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import java.util.ArrayList;

public class MoveEvent implements Event {
    float startX, startY;
    float endX, endY;
    BlobModel model;
    ArrayList<Groupable> movedBlobs;

    MoveEvent (ArrayList<Groupable> g, float startX, float endX, float startY, float endY, BlobModel model){
        this.startX = startX;
        this.endX = endX;
        this.startY = startY;
        this.endY = endY;
        movedBlobs = new ArrayList<>();
        for (Groupable b : g){
            movedBlobs.add(b);
        }
        this.model = model;
    }
    public void doIt(){
        float dx = endX - startX;
        float dy = endY - startY;
        model.move(movedBlobs, dx, dy);
    }

    public void undo(){
        float dx = startX - endX;
        float dy = startY - endY;
        System.out.println(movedBlobs == null);
        model.move(movedBlobs, dx, dy);
    }

    public String toString(){
        return ("Move Event, start = " + this.startX + " " + this.startY + ", end = " + this.endX + " " + this.endY);
    }
}

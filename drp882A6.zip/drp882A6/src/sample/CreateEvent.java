package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
public class CreateEvent implements Event {
    Blob theBlob;
    float theX, theY;
    BlobModel theModel;
    CreateEvent(Blob b, float x, float y, BlobModel model){
        theBlob = b;
        theX = x;
        theY = y;
        theModel = model;
    }
    public void doIt(){
        theModel.items.add(theBlob);
    }

    public void undo(){
        theModel.items.remove(theBlob);
    }

    public String toString(){
        return ("Create event, X = " + this.theX + " Y = " + this.theY);
    }
}

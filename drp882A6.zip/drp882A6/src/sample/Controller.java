package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
public class Controller {
}

package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class BlobModel {
    ArrayList<BlobModelListener> subscribers;
    ArrayList<Groupable> items;
    ArrayList<Event> undoStack = new ArrayList<>();
    ArrayList<Event> redoStack = new ArrayList<>();
    ObservableList<String> undoStrings = FXCollections.observableArrayList();
    ObservableList<String> redoStrings = FXCollections.observableArrayList();
    ListView undoList = new ListView();
    ListView redoList = new ListView();


    public BlobModel() {
        subscribers = new ArrayList<>();
        items = new ArrayList<>();
        undoList.setItems(undoStrings);
        redoList.setItems(redoStrings);
    }

    public void createBlob(double x, double y) {
        Blob b = new Blob(x, y);
        items.add(b);
        notifySubscribers();
    }

    public boolean checkHit(double x, double y) {
        return items.stream()
                .anyMatch(b -> b.contains(x, y));
    }

    public Groupable find(double x, double y) {
        Optional<Groupable> result = items.stream()
                .filter(g -> g.contains(x, y))
                .reduce((g1, g2) -> g2);
        if (result.isPresent()) {
            return result.get();
        } else {
            return null;
        }
    }

    public List<Groupable> findInRubberband(double x1, double y1, double x2, double y2) {
        return items.stream()
                .filter(g -> g.isContained(x1, y1, x2, y2))
                .collect(Collectors.toList());
    }

    public void move(List<Groupable> moveGroup, double dX, double dY) {
        moveGroup.forEach(g -> g.move(dX, dY));
        notifySubscribers();
    }

    public BlobGroup createGroup(ArrayList<Groupable> items) {
        this.items.removeAll(items);
        BlobGroup newGroup = new BlobGroup();
        items.forEach(g -> newGroup.add(g));
        this.items.add(newGroup);
        notifySubscribers();
        return newGroup;
    }

    public ArrayList<Groupable> unGroup(Groupable oldGroup) {
        oldGroup.getChildren().forEach(g -> items.add(g));
        items.remove(oldGroup);
        notifySubscribers();
        return oldGroup.getChildren();
    }

    public void addSubscriber(BlobModelListener aSub) {
        subscribers.add(aSub);
    }

    private void notifySubscribers() {
        subscribers.forEach(sub -> sub.modelChanged());
    }

    public void paste(ArrayList<Groupable> board){
        for (Groupable g : board){
            this.items.add(g);
        }
        notifySubscribers();
    }

    public void removeSome(ArrayList<Groupable> g){
        for (Groupable gs : g){
            this.items.remove(gs);
        }
        notifySubscribers();
    }

    public void undoFirst(){
        if (undoStack.size() == 0){
            return;
        }
        this.undoStack.get(undoStack.size()-1).undo();
        this.redoStack.add(undoStack.get(undoStack.size()-1));
        redoStrings.add(undoStack.get(undoStack.size()-1).toString());
        undoStrings.remove(undoStrings.size()-1);
        this.undoStack.remove(undoStack.get(undoStack.size()-1));
        notifySubscribers();
    }

    public void redoFirst(){
        if (redoStack.size() == 0){
            return;
        }
        this.redoStack.get(redoStack.size()-1).doIt();
        this.undoStack.add(this.redoStack.get(redoStack.size()-1));
        undoStrings.add(this.redoStack.get(redoStack.size()-1).toString());
        redoStrings.remove(redoStrings.size()-1);
        this.redoStack.remove(redoStack.get(redoStack.size()-1));
        notifySubscribers();
    }

    public void addUndoEvent(Event e){
        this.undoStack.add(e);
        undoStrings.add(e.toString());
    }


}

package sample;
/*
nsid: drp882
stud. #: 11201217
Cmpt 381 A6
*/
import java.util.ArrayList;

public class PasteEvent implements Event {
    ArrayList<Groupable> pastes = new ArrayList<>();
    BlobModel model;

    PasteEvent(ArrayList<Groupable> thePastes, BlobModel theModel){
        for (Groupable b : thePastes){
            pastes.add(b);
        }
        model = theModel;
    }

    public void doIt(){
        model.items.addAll(pastes);
    }

    public void undo(){
        model.removeSome(pastes);
    }

    public String toString(){
        return "Pasted " + pastes.size() + " things.";
    }
}

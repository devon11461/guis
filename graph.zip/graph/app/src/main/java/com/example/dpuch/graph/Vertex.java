package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

public class Vertex {
    float radius;
    float x, y;
    int id;
    public Vertex(float x, float y, int id){
        radius = (float)0.05;
        this.id = id;
        this.x = x;
        this.y = y;
    }
    public void setRadius(float radius){
        this.radius = radius;
    }
}

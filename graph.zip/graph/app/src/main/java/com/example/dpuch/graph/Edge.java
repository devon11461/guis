package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

public class Edge {
    float startX, startY;
    float endX, endY;
    int to, from;
    public Edge(float startX, float startY, float endX, float endY, int from, int to){
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.to = to;
        this.from = from;
    }
}

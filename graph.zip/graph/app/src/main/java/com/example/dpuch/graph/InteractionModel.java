package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import java.util.ArrayList;

public class InteractionModel {
    float mainViewWidth;
    float mainViewHeight;
    ArrayList<GraphModelListener> subs;
    float edgeX, edgeY;
    int selectedVertexId;
    boolean drawEdge, drawBorder;
    float vx, vy;
    public InteractionModel(){
        subs = new ArrayList<>();
        selectedVertexId = 0;
        drawEdge = false;
        drawBorder = false;
        vx = 0;
        vy = 0;
    }

    public void addSubscriber(GraphModelListener sub){
        subs.add(sub);
    }

    private void notifySubscribers(){
        for (GraphModelListener sub : subs){
            sub.GraphModelChanged();
        }
    }

    public void changeSelected(int id){
        this.selectedVertexId = id;
        notifySubscribers();
    }

    public void setEdge(float x, float y){
        edgeX = x;
        edgeY = y;
        notifySubscribers();
    }

    public void changeDrawEdge(){
        this.drawEdge = !this.drawEdge;
    }


}

package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;

public class MainGraphView extends View implements GraphModelListener{
    Paint paint;
    GraphModel myModel;
    InteractionModel IM;
    MainGraphController controller;

    public MainGraphView(Context aContext){
        super(aContext);
        paint = new Paint();
        this.setBackgroundColor(Color.GRAY);

    }

    public void setModel(GraphModel model){
        myModel = model;
    }

    public void setInteractionModel(InteractionModel IM) { this.IM = IM; }
    public void setController(final MainGraphController controller){
        this.setLongClickable(true);
        this.controller = controller;
        this.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return (controller.onTouchEvent(event));
            }
        });

        this.setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return controller.onLongClick();
            }
            });
        }

    public void onDraw(Canvas c){
        this.setBackgroundColor(Color.DKGRAY);
        if (IM != null){
            IM.mainViewWidth = this.getWidth();
            IM.mainViewHeight = this.getHeight();
        }
        for (Edge e : myModel.Edges){
            float startX = e.startX * 3000 - IM.vx;
            float startY = e.startY * 3000 - IM.vy;
            float endX = e.endX * 3000 - IM.vx;
            float endY = e.endY * 3000 - IM.vy;
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeWidth((float)0.01 * this.getWidth());
            c.drawLine(startX, startY, endX, endY, paint);
        }
        if (IM.selectedVertexId != 0 && IM.drawEdge){
            Vertex temp = myModel.getVertex(IM.selectedVertexId);
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeWidth((float)0.01 * this.getWidth());
            c.drawLine((temp.x * 3000) - IM.vx, (temp.y * 3000) - IM.vy, IM.edgeX * 3000 - IM.vx, IM.edgeY * 3000 - IM.vy, paint);
        }
        for (Vertex v : myModel.Vertices){
            float radius = v.radius * IM.mainViewWidth;
            float ratioX = v.x;
            float ratioY = v.y;
            float ourX = ratioX * 3000 - IM.vx;
            float ourY = ratioY * 3000 - IM.vy;

            if (this.IM.selectedVertexId == v.id){
                if (IM.drawBorder){
                    paint.setColor(Color.BLACK);
                    c.drawCircle(ourX, ourY, radius+10, paint);
                }
                paint.setColor(Color.YELLOW);
            }
            else {
                paint.setColor(Color.BLUE);
            }
            c.drawCircle(ourX, ourY, radius, paint);

            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(80);
            paint.setTextAlign(Paint.Align.CENTER);
            String hold  = "V" + v.id;
            c.drawText(hold, ourX, ourY, paint);
        }

    }

    public void GraphModelChanged(){
        invalidate();
    }


}


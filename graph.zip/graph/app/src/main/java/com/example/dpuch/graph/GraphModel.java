package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import java.util.ArrayList;

public class GraphModel {
    ArrayList<Vertex> Vertices;
    ArrayList<Edge> Edges;
    int VertexCount, EdgeCount;
    MainGraphController controller;
    ArrayList<GraphModelListener> subscribers;

    public GraphModel() {
        VertexCount = 0;
        EdgeCount = 0;
        Vertices = new ArrayList<>();
        Edges = new ArrayList<>();
        subscribers = new ArrayList<>();
    }
    public void setController(MainGraphController controller){
        this.controller = controller;
    }

    public void addEdge(float startX, float startY, float endX, float endY, int from, int to){
        EdgeCount += 1;
        Edge hold = new Edge(startX, startY, endX, endY, from, to);
        Edges.add(hold);
        notifySubscribers();
    }

    public void addVertex(float x, float y){
        VertexCount += 1;
        Vertex hold = new Vertex(x, y, VertexCount);
        Vertices.add(hold);
        notifySubscribers();
    }

    public void addSubscriber(GraphModelListener sub){
        subscribers.add(sub);
    }

    public void notifySubscribers(){
        for (GraphModelListener sub : subscribers){
            sub.GraphModelChanged();
        }
    }

    public int hitVertex(float x, float y){
        for (Vertex v : Vertices){
            if (v.x - v.radius <= x && v.x + v.radius >= x){
                if (v.y - v.radius <= y && v.y + v.radius >= y){
                    return v.id;
                }
            }
        }
        return 0;
    }

    public Vertex getVertex(int id){
        for (Vertex v : Vertices){
            if (v.id == id){
                return v;
            }
        }
        return null;
    }

}

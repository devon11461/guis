package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;
import android.widget.LinearLayout;

public class MiniGraphView extends View implements GraphModelListener {
    GraphModel model;
    InteractionModel IM;
    Paint paint;
    float dimension;

    public MiniGraphView(Context aContext) {
        super(aContext);
        paint = new Paint();
    }

    public void setDimension(float dim){
        dimension = dim;
        this.setLayoutParams(new LinearLayout.LayoutParams((int)dimension, (int)dimension));
    }
    public void setModel(GraphModel myModel){
        model = myModel;
    }

    public void setInteractionModel(InteractionModel IM){
        this.IM = IM;
    }

    public void onDraw(Canvas c){
        this.setBackgroundColor(Color.GRAY);
        if (model != null){
            for (Edge e : model.Edges){
                float startX = e.startX * this.dimension;
                float startY = e.startY * this.dimension;
                float endX = e.endX * this.dimension;
                float endY = e.endY * this.dimension;
                paint.setColor(Color.BLACK);
                paint.setStyle(Paint.Style.FILL);
                paint.setStrokeWidth((float)0.01 * this.dimension);
                c.drawLine(startX, startY, endX, endY, paint);
            }
            if (IM.selectedVertexId != 0 && IM.drawEdge){
                Vertex temp = model.getVertex(IM.selectedVertexId);
                paint.setColor(Color.BLACK);
                paint.setStyle(Paint.Style.FILL);
                paint.setStrokeWidth((float)0.01 * this.dimension);
                c.drawLine(temp.x * this.dimension, temp.y * this.dimension, IM.edgeX * dimension, IM.edgeY * dimension, paint);
            }
            for (Vertex v : model.Vertices){
                float radius = v.radius * this.dimension;
                float ratioX = v.x;
                float ratioY = v.y;
                float ourX = ratioX * this.dimension;
                float ourY = ratioY * this.dimension;
                if (this.IM.selectedVertexId == v.id){
                    if (IM.drawBorder){
                        paint.setColor(Color.BLACK);
                        c.drawCircle(ourX, ourY, radius+1, paint);
                    }
                    paint.setColor(Color.YELLOW);
                }
                else {
                    paint.setColor(Color.BLUE);
                }
                c.drawCircle(ourX, ourY, radius, paint);
            }

            float holdX = (IM.vx / 3000) * this.dimension;
            float holdY = (IM.vy / 3000) * this.dimension;
            paint.setColor(0xFFFFFFF);
            c.drawRect(holdX, holdY, holdX + ((IM.mainViewWidth / 3000) * this.dimension), holdY + ((IM.mainViewHeight / 3000) * this.dimension), paint);
        }

    }
    public void GraphModelChanged(){
        this.invalidate();
    }
}

package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import android.view.MotionEvent;

import java.util.Calendar;

public class MainGraphController {
    GraphModel model;
    InteractionModel IM;
    STATE myState;
    float mouseX, mouseY;
    boolean place;
    private long startClickTime;
    private static final int MAX_CLICK_DURATION = 200;

    private enum STATE{
        READY, PRESSED, MOVING, MOVING_BOARD;
    }

    MainGraphController(){
        myState = STATE.READY;
        place = true;
    }

    public void setModel(GraphModel model) {
        this.model = model;
    }

    public void setInteractionModel (InteractionModel IM) { this.IM = IM; }

    public boolean onTouchEvent(MotionEvent e) {
        if (model.hitVertex((e.getX() + IM.vx) / 3000, (e.getY() + IM.vy) / 3000) == 0 && IM.selectedVertexId == 0) {
            float x = e.getX();
            float y = e.getY();
            float width = IM.mainViewWidth;
            float height = IM.mainViewHeight;

            x = (x + IM.vx) / 3000;
            y = (y + IM.vy) / 3000;
            switch (e.getAction()) {
                case MotionEvent.ACTION_UP:
                    if (Calendar.getInstance().getTimeInMillis() - startClickTime < MAX_CLICK_DURATION) {
                        model.addVertex(x, y);
                    }
                case MotionEvent.ACTION_DOWN:
                    startClickTime = Calendar.getInstance().getTimeInMillis();
                    mouseX = (e.getX() / IM.mainViewWidth);
                    mouseY = (e.getY() / IM.mainViewHeight);

                case MotionEvent.ACTION_MOVE:
                    float changeX = (e.getX() / IM.mainViewWidth) - this.mouseX;
                    float changeY = ((e.getY() / IM.mainViewHeight) - this.mouseY);
                    if (IM.vx - (changeX * 3000) + IM.mainViewWidth > 3000 || IM.vx - (changeX * 3000) < 0){
                        changeX = 0;
                    }
                    if (IM.vy - (changeY * 3000) + IM.mainViewHeight > 3000 || IM.vy - (changeY * 3000) < 0){
                        changeY = 0;
                    }
                    IM.vx -= changeX * 3000;
                    IM.vy -= changeY * 3000;
                    mouseX = ((e.getX() / IM.mainViewWidth));
                    mouseY = ((e.getY() / IM.mainViewHeight));
                    model.notifySubscribers();
                    return true;
            }
        }
        else {
            switch (e.getAction()){
                case MotionEvent.ACTION_DOWN:
                    int holdId = model.hitVertex((e.getX() + IM.vx) / 3000, (e.getY()+ IM.vy) / 3000);
                    IM.changeSelected(holdId);
                    Vertex temp = model.getVertex(holdId);
                    IM.edgeX = (temp.x);
                    IM.edgeY = (temp.y);
                    //IM.edgeX = temp.x * IM.mainViewWidth;
                    //IM.edgeY = temp.y * IM.mainViewHeight;
                    return false;
            }
        }
        if (IM.selectedVertexId != 0){
            switch (e.getAction()){
                case MotionEvent.ACTION_UP:
                    if (this.myState == STATE.PRESSED) {
                        //int hit = model.hitVertex(e.getX() / IM.mainViewWidth, e.getY() / IM.mainViewHeight);
                        int hit = model.hitVertex((e.getX() + IM.vx) / 3000, (e.getY() + IM.vy) / 3000);
                        if (hit != 0 && hit != IM.selectedVertexId) {
                            Vertex end = model.getVertex(hit);
                            Vertex start = model.getVertex(IM.selectedVertexId);
                            float endX = end.x;
                            float endY = end.y;
                            float startX = start.x;
                            float startY = start.y;
                            model.addEdge(startX, startY, endX, endY, start.id, end.id);
                            IM.changeDrawEdge();
                        }
                        IM.edgeX = 0;
                        IM.edgeY = 0;
                    }
                    IM.drawEdge = false;
                    this.myState = STATE.READY;
                    IM.drawBorder = false;
                    IM.changeSelected(0);

                case MotionEvent.ACTION_MOVE:
                    if (this.myState == STATE.PRESSED) {
                        IM.setEdge((e.getX() + IM.vx) / 3000, (e.getY() + IM.vy) / 3000);
                    }
                    else {
                        if (IM.selectedVertexId != 0) {
                            Vertex hold = this.model.getVertex(this.IM.selectedVertexId);
                            float changeX = ((e.getX() + IM.vx) / 3000) - this.mouseX;
                            float changeY = ((e.getY() + IM.vy) / 3000) - this.mouseY;
                            for (Edge edge : model.Edges){
                                if (edge.from == IM.selectedVertexId){
                                    edge.startX += changeX;
                                    edge.startY += changeY;
                                }
                                else if (edge.to == IM.selectedVertexId){
                                    edge.endX += changeX;
                                    edge.endY += changeY;
                                }
                            }
                            hold.x += changeX;
                            hold.y += changeY;
                            mouseX = hold.x;
                            mouseY = hold.y;
                            model.notifySubscribers();
                            this.myState = STATE.MOVING;
                            return true;
                        }
                    }
            }


        }
        return true;
    }

    public boolean onLongClick(){
        if (this.myState == STATE.READY) {
            IM.drawBorder = true;
            this.myState = STATE.PRESSED;
            model.notifySubscribers();
            IM.changeDrawEdge();
        }
            return true;

    }
}

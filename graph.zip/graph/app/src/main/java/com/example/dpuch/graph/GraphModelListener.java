package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

public interface GraphModelListener {
    public void GraphModelChanged();
}

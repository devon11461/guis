package com.example.dpuch.graph;

/*
drp882
11201217
CMPT381 A3
 */

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    MainGraphView view;
    MiniGraphView miniView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainGraphController controller = new MainGraphController();
        GraphModel graph = new GraphModel();
        view = new MainGraphView(this);
        miniView = new MiniGraphView(this);

        LinearLayout myLayout = new LinearLayout(this);
        myLayout.setOrientation(LinearLayout.VERTICAL);
        myLayout.addView(miniView);
        myLayout.addView(view);

        setContentView(myLayout);
        InteractionModel IM = new InteractionModel();
        view.setModel(graph);
        graph.setController(controller);
        view.setController(controller);
        controller.setModel(graph);
        graph.addSubscriber(view);
        controller.setInteractionModel(IM);
        view.setInteractionModel(IM);
        IM.addSubscriber(view);

        IM.addSubscriber(miniView);
        graph.addSubscriber(miniView);
        miniView.setDimension(500);
        miniView.setModel(graph);
        miniView.setInteractionModel(IM);

    }
}

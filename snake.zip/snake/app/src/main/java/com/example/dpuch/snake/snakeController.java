package com.example.dpuch.snake;

import android.view.MotionEvent;
import android.view.GestureDetector;
public class snakeController extends GestureDetector.SimpleOnGestureListener{
    private snakeModel model;
    float startX;
    float startY;
    float endX;
    float endY;

    private static int MIN_SWIPE_DISTANCE_X = 100;
    private static int MIN_SWIPE_DISTANCE_Y = 100;

    private static int MAX_SWIPE_DISTANCE_X = 1000;
    private static int MAX_SWIPE_DISTANCE_Y = 1000;

    private main activity = null;

    public void setActivity(main activity){
        this.activity = activity;
    }

    /**
     * onFling(...): A method responsible for recognizing and responding to directional swipes.
     * @param e1 MotionEvent: The touch down point for the first point of contact of the touch.
     * @param e2 MotionEvent: The motion event for releasing the swipe gesture.
     * @param velocityX float: The velocity that the swipe occurred (x-direction)
     * @param velocityY float: The velocity that the swipe occurred (y-direction).
     * @return boolean: True if the event is consumed, false otherwise.
     */
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY){
        float deltaX = e1.getX() - e2.getX();
        float deltaY = e1.getY() - e2.getY();

        float deltaXAbs = Math.abs(deltaX);
        float deltaYAbs = Math.abs(deltaY);

        if ((deltaXAbs >= MIN_SWIPE_DISTANCE_X) && (deltaXAbs <= MAX_SWIPE_DISTANCE_X)){
            if (deltaX > 0){
                if (this.model.can_change_to(direction.LEFT)) {
                    this.model.changeDirection(direction.LEFT);
                }
            } else {
                if (this.model.can_change_to(direction.RIGHT)) {
                    this.model.changeDirection(direction.RIGHT);
                }
            }
        } else if ((deltaYAbs >= MIN_SWIPE_DISTANCE_Y) && (deltaYAbs <= MAX_SWIPE_DISTANCE_Y)){
            if (deltaY > 0){
                if (this.model.can_change_to(direction.UP)) {
                    this.model.changeDirection(direction.UP);
                }
            } else {
                if (this.model.can_change_to(direction.DOWN)) {
                    this.model.changeDirection(direction.DOWN);
                }
            }
        }
        return true;
    }

    /**
     * Empty constructor.
     */
    snakeController() {

    }

    /**
     * setModel(snakeModel): A method responsible for setting the model that this controller
     * will manipulate.
     * @param m snakeModel: The model that we wish to manipulate.
     */
    public void setModel(snakeModel m){
        this.model = m;
    }


}

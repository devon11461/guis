package com.example.dpuch.snake;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Queue;

public class snakeModel {
    ArrayList<location> snake;
    direction theDirection = direction.DOWN;
    int size = 3;
    ArrayList<ModelListener> subs = new ArrayList<>();
    location food = new location(16, 10);
    private int horizontal_tiles = 20;
    private int vertical_tiles = 20;

    /**
     * Initialization
     *  Creates a snake of size 3, with pieces at (10, 10), (11, 10), and (12, 10).
     */
    snakeModel(){
        snake = new ArrayList<>();
        this.addLocation(10, 10);
        this.addLocation(11, 10);
        this.addLocation(12, 10);
    }


    /**
     * Shift: A method that moves out the first element of our snake. Used for movement.
     */
    public void shift(){
        this.snake.remove(0);
    }

    /**
     * moveLeft(): A method that moves our snake one to the left. Will first shift how ever
     * many times it needs to , then add one a new spot to the end of the array list that is
     * one x-coordinate left of where the last spot was.
     */
    public void moveLeft(){
        while (snake.size() >= size){
            shift();
        }
        snake.add(new location(snake.get(snake.size()-1).x - 1, snake.get(snake.size()-1).y));
        return;
    }

    /**
     * moveRight(): A method that moves our snake one to the Right. Will first shift how ever
     * many times it needs to , then add one a new spot to the end of the array list that is
     * one x-coordinate right of where the last spot was.
     */
    public void moveRight(){
        while (snake.size() >= size){
            shift();
        }
        snake.add(new location(snake.get(snake.size()-1).x + 1, snake.get(snake.size()-1).y));
        return;
    }

    /**
     * moveDown(): A method that moves our snake one down. Will first shift how ever
     * many times it needs to , then add one a new spot to the end of the array list that is
     * one y-coordinate down of where the last spot was.
     */
    public void moveDown(){
        while (snake.size() >= size){
            shift();
        }
        snake.add(new location(snake.get(snake.size()-1).x, snake.get(snake.size()-1).y + 1));
        return;
    }

    /**
     * moveUp(): A method that moves our snake one up. Will first shift how ever
     * many times it needs to , then add one a new spot to the end of the array list that is
     * one y-coordinate up of where the last spot was.
     */
    public void moveUp(){
        while (snake.size() >= size){
            shift();
        }
        snake.add(new location(snake.get(snake.size()-1).x, snake.get(snake.size()-1).y - 1));
        return;
    }

    /**
     * set_tiles(int, int): A method responsible for telling us how many tiles our
     * user can have left and right. Used for wall-hit detection. Different device-to-device.
     * @param h Integer the number of tiles we have horizontally.
     * @param v Integer the number of tiles we have vertically.
     */
    public void set_tiles(int h, int v){
        if (h < 0 || v < 0){
            return;
        }
        this.horizontal_tiles = h;
        this.vertical_tiles = v;
    }

    /**
     * addSubscriber(ModelListener): A method that adds a subscriber to our list of subs.
     * We will notify these subs whenever something in our model changes.
     * @param s ModelListener - A view that needs to be updated when the model changes.
     */
    public void addSubscriber(ModelListener s){
        this.subs.add(s);
    }

    /**
     * addLocation(int, int): A method responsible for adding another piece to our snake.
     * Will also do this when we move, even if we're not adding.
     * @param newX Integer - the x location we're adding to the snake.
     * @param newY Integer - the y location we're adding to the snake.
     */
    public void addLocation(int newX, int newY){
        this.snake.add(new location(newX, newY));
    }

    /**
     * changeDirection(direction): A method that will be called whenever a user gestures on the
     * screen a reasonable amount. This will just change the direction the snake is moving.
     * @param dir direction - the new direction the snake will be moving.
     */
    public void changeDirection(direction dir){
        this.theDirection = dir;
    }

    /**
     * move(): A method responsible for moving the snake. Will switch based off of what
     * direction we're supposed to be moving.
     * This method will also check if we hit food, the wall or ourself. If the snake hits food,
     * it will grow one, a new food will be generated, and it's size will increase by 1.
     * If it hits a wall or itself, the game will reset.
     * The view will be notified.
     */
    public void move(){
        switch (this.theDirection){
            case UP:
                moveUp();
                break;
            case DOWN:
                moveDown();
                break;
            case LEFT:
                moveLeft();
                break;
            case RIGHT:
                moveRight();
                break;
            default:
                return;
        }
        if (checkHitFood()){
            new_food();
            size++;
        }
        if (checkHitWall()){
            reset();
        }
        if (checkHitSelf()){
            reset();
        }
        notifySubscribers();
    }

    /**
     * notifySubscribers(): A method responsible for telling our subscribed views that
     * the model has changed and the view needs to update.
     */
    public void notifySubscribers(){
        for (ModelListener ms : subs){
            ms.onModelChange();
        }
    }

    /**
     * can_change_to(direction): A method responsible for checking if, given our current direction,
     * the new direction is allowable.
     * @param d direction - the direction that we're checking if it is allowable.
     * @return boolean - True if we are allowed to move in this new direction, false otherwise.
     */
    public boolean can_change_to(direction d){
        switch (this.theDirection){
            case DOWN:
                return d != direction.UP;
            case UP:
                return d != direction.DOWN;
            case LEFT:
                return d != direction.RIGHT;
            case RIGHT:
                return d != direction.LEFT;
            default:
                return false;
        }
    }

    /**
     * new_food(): A method responsible for generating a new piece of food. Will be called whenever
     * we eat the old food. Tells view to redraw.
     */
    public void new_food(){
        int foodX = (int)(Math.random() * (horizontal_tiles-1));
        int foodY = (int)(Math.random() * (vertical_tiles-1));
        this.food.x = foodX;
        this.food.y = foodY;
        notifySubscribers();
    }

    /**
     * checkHitFood(): A method that checks if the front of our snake hit the piece of food.
     * @return boolean - True if our snake did hit the food (snake head and food locations are the same), false otherwise.
     */
    public boolean checkHitFood(){
        if (this.snake.get(snake.size() - 1).x == food.x){
            if (this.snake.get(snake.size() - 1) . y == food.y){
                return true;
            }
        }
        return false;
    }

    /**
     * checkHitWall(): A method responsible for seeing if the head of our snake hit the edge of the game.
     * @return boolean - True if the snake hit the edge of the game, false otherwise.
     */
    public boolean checkHitWall(){
        return (snake.get(snake.size()-1).x >= horizontal_tiles ||
                snake.get(snake.size()-1). x < 0                ||
                snake.get(snake.size()-1).y < 0                 ||
                snake.get(snake.size()-1).y >= vertical_tiles     );
    }

    /**
     * reset(): A method responsible for resetting the game when the snake dies.
     * Clears all snake locations, fills them with the defaults mentioned at initialization,
     * and sets the size to 3. Tells the subscribed views to redraw.
     */
    public void reset(){
        snake.clear();
        size = 3;
        this.addLocation(10, 10);
        this.addLocation(11, 10);
        this.addLocation(12, 10);
        notifySubscribers();
    }

    /**
     * checkHitSelf(): A method responsible for checking if the snake hit itself.
     * @return boolean - True if the snake did hit another part of itself, false otherwise.
     */
    public boolean checkHitSelf(){
        int x = snake.get(snake.size() - 1).x;
        int y = snake.get(snake.size() - 1).y;
        for (int i = 0; i < snake.size() - 2; i++){
            int checkX = snake.get(i).x;
            int checkY = snake.get(i).y;
            if (checkX == x && checkY == y){
                return true;
            }
        }
        return false;
    }

}

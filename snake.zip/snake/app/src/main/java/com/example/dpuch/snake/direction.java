package com.example.dpuch.snake;

/**
 * direction: An enumerated type that represents the directions that our snake is moving.
 */
public enum direction {
    LEFT, RIGHT, DOWN, UP, NONE;
}

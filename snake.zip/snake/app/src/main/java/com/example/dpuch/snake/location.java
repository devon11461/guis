package com.example.dpuch.snake;

public class location {
    int x;
    int y;

    location(int newX, int newY){
        x = newX;
        y = newY;
    }

    public void moveLeft(){
        x--;
    }

    public void moveRight(){
        x++;
    }

    public void moveUp(){
        y--;
    }

    public void moveDown(){
        y++;
    }
}

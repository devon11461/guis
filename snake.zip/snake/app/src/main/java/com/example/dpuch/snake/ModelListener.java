package com.example.dpuch.snake;

/**
 * ModelListener : An interface for any views that need to respond to model changes.
 */
public interface ModelListener {
    public void onModelChange();
}

package com.example.dpuch.snake;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class snakeView extends View implements ModelListener {
    Paint paint = new Paint();
    snakeModel model;
    float width = this.getWidth();
    float height = this.getHeight();

    /**
     * snakeView(context): A method responsible for creating a new snake view.
     * @param aContext Context - the context that we're drawing on.
     */
    snakeView(Context aContext){
        super(aContext);
        this.setBackgroundColor(Color.BLACK);
    }

    /**
     * setModel(snakeModel): A method responsible for setting the model for our view, so our view
     * knows what to draw.
     * @param m snakeModel - The model our view is supposed to draw.
     */
    public void setModel(snakeModel m){
        model = m;
        invalidate();
    }

    /**
     * onDraw(Canvas): A method responsible for drawing the view's model. Additionally sets the width and height of the game.
     * @param c Canvas - the canvas that we're drawing on.
     */
    public void onDraw(Canvas c){
        this.width = this.getWidth();
        this.height = this.getHeight();
        int tileWidth = this.getWidth() / 20;
        int tileHeight = tileWidth;

        if (this.getWidth() != 0){
            model.set_tiles(this.getWidth()/tileWidth, this.getHeight()/tileHeight);
        }

        if (model != null){
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.RED);
            for (location l : this.model.snake) {
                float left = l.x * tileWidth;
                float top = l.y * tileHeight;
                float bottom = top + tileHeight - 2;
                float right = left + tileWidth - 2;
                c.drawRect(left, top, right, bottom, this.paint);
            }

            paint.setColor(Color.GREEN);
            c.drawRect(model.food.x * tileWidth, model.food.y * tileHeight,
                    (model.food.x * tileWidth) + tileWidth - 2,
                          (model.food.y * tileHeight) + tileHeight - 2, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(60f);
            c.drawText("Score: " + (model.size - 3), 10, 50, paint);
        }
    }

    /**
     * onModelChange(): The method called whenever the model changes. Will cause the view
     * to redraw it's model.
     */
    public void onModelChange(){
        invalidate();
    }


}

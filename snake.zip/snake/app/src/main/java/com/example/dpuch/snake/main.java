package com.example.dpuch.snake;
import android.content.Intent;
import android.os.Build;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Timer;
import java.util.TimerTask;

public class main extends AppCompatActivity {
    private GestureDetectorCompat gestureDetectorCompat = null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final snakeModel model = new snakeModel();
        LinearLayout l = new LinearLayout(this);
        Button b = new Button(this);
        b.setHeight(100);
        b.setWidth(1440);
        b.setText("Back");
        model.theDirection = direction.DOWN;
        snakeView theView = new snakeView(this);
        theView.setModel(model);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(b);
        layout.addView(theView);
        setContentView(layout);
        model.addSubscriber(theView);
        snakeController controller = new snakeController();
        controller.setActivity(this);
        controller.setModel(model);

        gestureDetectorCompat = new GestureDetectorCompat(this, controller);

        new Timer().scheduleAtFixedRate(new TimerTask(){
            @Override
            public void run(){
                model.move();
            }
        }, 0, 1000/5);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(main.this, menu.class));
            }
        });
    }

    public boolean onTouchEvent(MotionEvent event){
        gestureDetectorCompat.onTouchEvent(event);
        return true;
    }
}

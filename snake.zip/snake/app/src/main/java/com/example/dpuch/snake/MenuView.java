package com.example.dpuch.snake;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MenuView extends LinearLayout {
    Button b;

    /**
     * Constructor for our Menu layout.
     * @param aContext Context: The context that is where we will show this layout.
     */
    MenuView(Context aContext){
        super(aContext);
        drawMenu();
        this.setOrientation(VERTICAL);
        this.addView(b);
    }

    /**
     * drawMenu(): Method responsible for drawing the menu for our snake game.
     */
    public void drawMenu() {
        TextView t = new TextView(this.getContext());
        t.setText("Welcome to Devon's Snake!");
        t.setWidth(1000);
        t.setHeight(1000);
        t.setX(300);
        t.setTextSize(20f);
        t.setTextColor(Color.WHITE);
        b = new Button(this.getContext());
        b.setX(0);

        b.setWidth(100);
        b.setHeight(100);
        b.setText("Click me to play snake!");
        this.addView(t);
    }

}

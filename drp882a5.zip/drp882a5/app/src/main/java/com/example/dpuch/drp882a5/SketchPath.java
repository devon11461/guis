package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.graphics.Path;
import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;

public class SketchPath {
    ArrayList<Float> xs, ys;
    Path path = new Path();
    int thinning = 1;

    SketchPath(){
        xs = new ArrayList<>();
        ys = new ArrayList<>();
    }

    public void setThinning(int newT){
        thinning = newT;
        if (xs.size() != 0){
            calculatePath();
        }
    }

    public void calculatePath(){
        if (xs.size() < 1){
            return;
        }
        path = new Path();
        path.moveTo(xs.get(0), ys.get(0));
        if (xs.size() < thinning){
            float midX = (xs.get(0) + xs.get(xs.size()-1))/2;
            float midY = (ys.get(0) + ys.get(ys.size()-1))/2;
            path.quadTo(xs.get(0), ys.get(0), midX, midY);
            return;
        }
        for (int i = 0; i < xs.size(); i+=thinning){
            if (i+thinning >= xs.size()){
                float midX = (xs.get(i) + xs.get(xs.size()-1))/2;
                float midY = (ys.get(i) + ys.get(ys.size()-1))/2;
                path.quadTo(xs.get(i), ys.get(i), midX, midY);
                return;
            } else {
                float midX = (xs.get(i) + xs.get(i+thinning))/2;
                float midY = (ys.get(i) + ys.get(i+thinning))/2;
                path.quadTo(xs.get(i), ys.get(i), midX, midY);
            }
        }
        return;
    }

    public void addPoints(ArrayList<Float> x, ArrayList<Float> y){
        xs.clear();
        xs = (ArrayList<Float>)x.clone();
        ys = (ArrayList<Float>)y.clone();
        calculatePath();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkHit(float x, float y){
        float[] approxPoints = this.path.approximate((float)0.5);
        for (int i = 1; i < approxPoints.length; i+=3){
            if (distance(x, y, approxPoints[i], approxPoints[i+1]) < 15){
                return true;
            }
        }
        return false;
    }

    public double distance(float x1, float y1, float x2, float y2){
        return (Math.sqrt( Math.pow((x2-x1), 2) + Math.pow( (y2-y1), 2)));
    }

    public void move(float x, float y){
        for (int i = 0; i < xs.size(); i++){
            xs.set(i, xs.get(i)+x);
            ys.set(i, ys.get(i)+y);
        }
        calculatePath();
    }

    public void resize(float x, float y, float left, float top){
        for (int i = 0; i < xs.size(); i++){
            xs.set(i, (xs.get(i)-left)*x+left);
            ys.set(i, (ys.get(i)-top)*y+top);
        }
        calculatePath();
    }
}

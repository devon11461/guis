package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

public interface SketchListener {
    public void onModelChange();
}

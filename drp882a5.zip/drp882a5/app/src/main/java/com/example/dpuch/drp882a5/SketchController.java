package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.MotionEvent;

public class SketchController {
    private enum STATE{
        READY, DRAWING, DRAGGING, RESIZING;
    }

    private SketchModel model;
    private InteractionModel iModel;
    private STATE myState = STATE.READY;
    private float oX, oY, height, width;

    SketchController(){

    }

    public void setModel(SketchModel m){
        model = m;
    }

    public void setInteractionModel(InteractionModel im){
        iModel = im;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean onTouch(MotionEvent e){
        switch (e.getAction()){
            case MotionEvent.ACTION_DOWN:
                switch (myState){
                    case READY:
                        if (model.checkHit(e.getX(), e.getY())){
                            iModel.setSelectedPath(model.getHit(e.getX(), e.getY()));
                            myState = STATE.DRAGGING;
                            oX = e.getX();
                            oY = e.getY();
                        } else if (iModel.checkHitCircle(e.getX(), e.getY())){
                            height = iModel.getBottom() - iModel.getTop();
                            width = iModel.getRight() - iModel.getLeft();
                            myState = STATE.RESIZING;
                            return true;
                        } else {
                            iModel.clearSelection();
                            myState = STATE.DRAWING;
                        }
                        return true;
                }
            case MotionEvent.ACTION_MOVE:
                switch (myState){
                    case DRAWING:
                        iModel.addPoint(e.getX(), e.getY());
                        return true;
                    case DRAGGING:
                        float diffX = e.getX() - oX;
                        float diffY = e.getY() - oY;
                        iModel.moveSelectedPath(diffX, diffY);
                        oX = e.getX();
                        oY = e.getY();
                        return true;
                    case RESIZING:
                        float newHeight = e.getY() - iModel.getTop();
                        float newWidth = e.getX() - iModel.getLeft();
                        float ratioY = newHeight / height;
                        float ratioX = newWidth  / width;
                        iModel.resizeSelected(ratioX, ratioY, iModel.getLeft(), iModel.getTop());
                        height = iModel.getBottom() - iModel.getTop();
                        width = iModel.getRight() - iModel.getLeft();
                        return true;
                }
            case MotionEvent.ACTION_UP:
                switch (myState){
                    case DRAWING:
                        myState = STATE.READY;
                        model.addPath(iModel.xs, iModel.ys);
                        iModel.clearPath();
                        return true;
                    case DRAGGING:
                        myState = STATE.READY;
                        return true;
                    case RESIZING:
                        myState = STATE.READY;
                }
        }
        return true;
    }
}

package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;

public class SketchModel {
    ArrayList<SketchPath> paths = new ArrayList<>();
    ArrayList<SketchListener> subscribers = new ArrayList<>();
    public int thinning = 1;

    SketchModel(){

    }

    public void addPath(ArrayList<Float> xs, ArrayList<Float> ys){
        SketchPath hold = new SketchPath();
        hold.setThinning(thinning);
        hold.addPoints(xs, ys);
        paths.add(hold);
        notifySubscribers();
    }

    public void notifySubscribers(){
        for (SketchListener s : subscribers){
            s.onModelChange();
        }
    }

    public void addSubscriber(SketchListener s){
        subscribers.add(s);
    }

    public void setThinning(int i){
        thinning = i;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkHit(float x, float y){
        for (SketchPath p : paths){
            if (p.checkHit(x, y)) {
                return true;
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public SketchPath getHit(float x, float y){
        for (SketchPath p : paths){
            if (p.checkHit(x, y)){
                return p;
            }
        }
        return null;
    }

    public void clear(){
        paths.clear();
        notifySubscribers();
    }
}

package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.graphics.Path;
import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;

public class InteractionModel {
    ArrayList<SketchListener> subscribers;
    ArrayList<Float> xs, ys;
    Path drawnPath = new Path();
    SketchPath selectedPath = null;
    InteractionModel(){
        subscribers = new ArrayList<>();
        xs = new ArrayList<>();
        ys = new ArrayList<>();
    }

    public void calculatePath(){
        drawnPath = new Path();
        if (xs.size() < 1){
            return;
        }
        drawnPath.moveTo(xs.get(0), ys.get(0));
        for (int i = 1; i < xs.size(); i++){
            drawnPath.quadTo(xs.get(i-1), ys.get(i-1), xs.get(i), ys.get(i));
        }
    }

    public void clearPath(){
        xs.clear();
        ys.clear();
        drawnPath = new Path();
        notifySubscribers();
    }

    public void addPoint(float x, float y){
        xs.add(x);
        ys.add(y);
        calculatePath();
        notifySubscribers();
    }

    public void addSubscriber(SketchListener s){
        subscribers.add(s);
    }

    public void notifySubscribers(){
        for (SketchListener s : subscribers){
            s.onModelChange();
        }
    }

    public void setSelectedPath(SketchPath p){
        this.selectedPath = p;
        notifySubscribers();
    }

    public void clearSelection(){
        this.selectedPath = null;
        notifySubscribers();
    }

    public void moveSelectedPath(float x, float y){
        selectedPath.move(x, y);
        notifySubscribers();
    }

    public void setSelectedThinning(int i){
        selectedPath.setThinning(i);
        notifySubscribers();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public float getLeft(){
        if (selectedPath != null){
            float min = Float.MAX_VALUE;
            float[] pts = selectedPath.path.approximate((float)0.5);
            for (int i = 1; i < pts.length; i+=3){
                if (pts[i] < min){
                    min = pts[i];
                }
            }
            return min;
        }
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public float getTop(){
        if (selectedPath != null){
            float min = Float.MAX_VALUE;
            float[] pts = selectedPath.path.approximate((float)0.5);
            for (int i = 2; i < pts.length; i+=3){
                if (pts[i] < min){
                    min = pts[i];
                }
            }
            return min;
        }
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public float getBottom(){
        if (selectedPath != null){
            float max = 0;
            float[] pts = selectedPath.path.approximate((float)0.5);
            for (int i = 2; i < pts.length; i+=3){
                if (pts[i] > max){
                    max = pts[i];
                }
            }
            return max;
        }
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public float getRight(){
        if (selectedPath != null){
            float max = 0;
            float[] pts = selectedPath.path.approximate((float)0.5);
            for (int i = 1; i < pts.length; i+=3){
                if (pts[i] > max){
                    max = pts[i];
                }
            }
            return max;
        }
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkHitCircle(float x, float y){
        if (selectedPath == null){
            return false;
        }
        return (distance(x, y, getRight(), getBottom()) < 30);
    }

    public double distance(float x1, float y1, float x2, float y2){
        return (Math.sqrt( Math.pow((x2-x1), 2) + Math.pow( (y2-y1), 2)));
    }

    public void resizeSelected(float x, float y, float left, float top){
        selectedPath.resize(x, y, left, top);
        notifySubscribers();
    }

}

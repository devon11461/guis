package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;

public class MainSketchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        final SketchView view = new SketchView(this);
        final InteractionModel iModel = new InteractionModel();
        final SketchController controller = new SketchController();
        final SketchModel model = new SketchModel();
        final SeekBar bar = new SeekBar(this);
        bar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.setMax(9);
        Button button = new Button(this);
        button.setText("Click me to delete everything!");
        button.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                model.clear();
                iModel.clearSelection();
                iModel.clearPath();
            }
        });
        controller.setInteractionModel(iModel);
        controller.setModel(model);

        view.setModel(model);
        view.setInteractionModel(iModel);

        iModel.addSubscriber(view);
        model.addSubscriber(view);

        layout.addView(bar);
        layout.addView(button);
        layout.addView(view)
        ;
        setContentView(layout);

        view.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return controller.onTouch(event);
            }
        });

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (iModel.selectedPath != null){
                    iModel.setSelectedThinning(progress+1);
                }
                model.setThinning(progress+1);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}

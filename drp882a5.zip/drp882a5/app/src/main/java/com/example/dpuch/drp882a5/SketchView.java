package com.example.dpuch.drp882a5;

/*
drp882
11201217
devon puchailo
CMPT381 A5
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.FitWindowsLinearLayout;
import android.view.View;

public class SketchView extends View implements SketchListener {
    Paint paint = new Paint();
    private InteractionModel iModel;
    private SketchModel model;

    SketchView(Context aContext){
        super(aContext);
        this.setBackgroundColor(Color.BLACK);
    }

    public void setModel(SketchModel m){
        model = m;
    }

    public void setInteractionModel(InteractionModel im){
        iModel = im;
    }

    public void onModelChange(){
        invalidate();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onDraw(Canvas c){
        if (model != null){
            for (SketchPath p : model.paths){
                paint.setColor(Color.GRAY);
                paint.setStyle(Paint.Style.FILL);
                for (int i = 0; i < p.xs.size(); i++){
                    c.drawCircle(p.xs.get(i), p.ys.get(i), 20, paint);
                }
                if (iModel != null & iModel.selectedPath != null && p == iModel.selectedPath){
                        paint.setColor(Color.RED);
                }  else {
                    paint.setColor(Color.BLUE);
                }
                paint.setStyle(Paint.Style.STROKE);
                c.drawPath(p.path, paint);
            }
        }
        if (iModel != null){
            if (iModel.selectedPath != null){
                paint.setColor(Color.WHITE);
                paint.setStrokeWidth(10);
                c.drawRect(iModel.getLeft(), iModel.getTop(), iModel.getRight(), iModel.getBottom(), paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.YELLOW);
                c.drawCircle(iModel.getRight(), iModel.getBottom(), 30, paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(15);
            paint.setColor(Color.GREEN);
            c.drawPath(iModel.drawnPath, paint);
        }
    }

}
